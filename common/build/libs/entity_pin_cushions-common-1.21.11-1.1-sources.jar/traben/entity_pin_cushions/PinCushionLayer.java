package traben.entity_pin_cushions;

import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.*;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3879;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4507;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_5819;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import net.minecraft.class_954;
import net.minecraft.class_9940;
import net.minecraft.class_9942;

public abstract class PinCushionLayer<T extends class_10042, M extends class_583<T>> extends class_3887<T, M> {

    protected class_4507.class_9995 placementStyle;
    private final class_3879 model;
    private final class_2960 texture;

    public PinCushionLayer(final class_3883<T, M> renderer, final class_3879 model, final class_2960 texture, final class_4507.class_9995 placementStyle) {
        super(renderer);
        this.model = model;
        this.texture = texture;
        this.placementStyle = placementStyle;
    }

    protected abstract int numStuck(T renderState);

    private void renderStuckItem(class_4587 poseStack, class_11659 submitNodeCollector, int packedLight, float x, float y, float z) {
        float f = class_3532.method_15355(x * x + z * z);
        float g = (float) (Math.atan2((double) x, (double) z) * (double) (180F / (float) Math.PI));
        float h = (float) (Math.atan2((double) y, (double) f) * (double) (180F / (float) Math.PI));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(g - 90.0F));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(h));
        // Counter-scale so the stuck item keeps its real-world size regardless of whatever
        // ambient scale is already baked into the current PoseStack at this point (large/small
        // Slimes use a non-uniform, animated "squish" scale that isn't exposed via a simple
        // renderState field, babies use a uniform scale, etc.). Reading the scale straight out
        // of the pose matrix's basis vectors works no matter what caused it.
        Matrix4f pose = poseStack.method_23760().method_23761();
        float scaleX = pose.transformDirection(new Vector3f(1.0F, 0.0F, 0.0F)).length();
        float scaleY = pose.transformDirection(new Vector3f(0.0F, 1.0F, 0.0F)).length();
        float scaleZ = pose.transformDirection(new Vector3f(0.0F, 0.0F, 1.0F)).length();
        if (scaleX > 1.0E-5F && scaleY > 1.0E-5F && scaleZ > 1.0E-5F) {
            poseStack.method_22905(1.0F / scaleX, 1.0F / scaleY, 1.0F / scaleZ);
        }
        // Since the 1.21.9 rendering rewrite, models are no longer drawn immediately via a
        // VertexConsumer - they get submitted to the SubmitNodeCollector for deferred/batched
        // rendering instead. submitModelPart() replaces the old model.renderToBuffer(...) call.
        submitNodeCollector.method_73491(this.model.method_63512(), poseStack, this.model.method_23500(this.texture), packedLight, class_4608.field_21444, null);
    }

    @Override
    public void submit(final class_4587 poseStack, final class_11659 submitNodeCollector, final int packedLight, final T renderState, final float yRot, final float xRot) {
        int[] data = EntityPinCushions.PINCUSHION_DATA.get(renderState);
        int pinCushionId = data != null ? data[0] : 0;
        int i = numStuck(renderState);
        class_5819 randomSource = class_5819.method_43049(pinCushionId);
        if (i > 0) {
            for (int j = 0; j < i; ++j) {
                Random partRand = new Random(j);
                poseStack.method_22903();
                M model = method_17165();

                Pair<class_630, Runnable> modelPart = bestFromListMutable(new ArrayList<>(model.method_63512().field_3661.values()), partRand, poseStack, true);

                if (modelPart == null) {
                    poseStack.method_22909();
                    return;
                }

                modelPart.getSecond().run();//transforms

                float f = randomSource.method_43057();
                float g = randomSource.method_43057();
                float h = randomSource.method_43057();

                if (this.placementStyle == class_4507.class_9995.field_53233) {
                    int n = randomSource.method_43048(3);
                    switch (n) {
                        case 0 -> f = snapToFace(f);
                        case 1 -> g = snapToFace(g);
                        default -> h = snapToFace(h);
                    }
                }

                if (!modelPart.getFirst().field_3663.isEmpty()) {
                    class_630.class_628 cube = modelPart.getFirst().method_22700(randomSource);
                    float k = class_3532.method_16439(f, cube.field_3645, cube.field_3648) / 16.0F;
                    float l = class_3532.method_16439(g, cube.field_3644, cube.field_3647) / 16.0F;
                    float m = class_3532.method_16439(h, cube.field_3643, cube.field_3646) / 16.0F;
                    poseStack.method_46416(k, l, m);
                }

                f = -1.0F * (f * 2.0F - 1.0F);
                g = -1.0F * (g * 2.0F - 1.0F);
                h = -1.0F * (h * 2.0F - 1.0F);
                this.renderStuckItem(poseStack, submitNodeCollector, packedLight, f, g, h);
                poseStack.method_22909();
            }

        }
    }

    private static float snapToFace(float value) {
        return value > 0.5F ? 1.0F : 0.5F;
    }

    @Nullable
    private Pair<class_630, Runnable> bestFromListMutable(List<class_630> partsMutable, Random randomSource, class_4587 poseStack, boolean firstIteration) {
        Collections.shuffle(partsMutable, randomSource);
        //try children instead
        for (class_630 modelPart : partsMutable) {
            if (modelPart.field_3665) {
                if (!modelPart.field_3663.isEmpty() && !modelPart.field_38456) {
                    return Pair.of(modelPart, () -> modelPart.method_22703(poseStack));
                }
                if (modelPart.field_3661.isEmpty()) continue;

                var child = bestFromListMutable(new ArrayList<>(modelPart.field_3661.values()), randomSource, poseStack, false);
                if (child != null) {
                    var runnable = child.getSecond();
                    return Pair.of(child.getFirst(), () -> {
                        modelPart.method_22703(poseStack);
                        runnable.run();
                    });
                }
            }
        }
        if (firstIteration && !partsMutable.isEmpty()) {
            //noinspection SequencedCollectionMethodCanBeUsed
            var part = partsMutable.get(0);
            return Pair.of(part, () -> part.method_22703(poseStack));
        }
        return null;
    }

    public static class ArrowLayer<T extends class_10042, M extends class_583<T>> extends PinCushionLayer<T, M> {

        public ArrowLayer(class_5617.class_5618 context, class_922<?, T, M> renderer) {
            super(renderer,
                    new class_9940(context.method_32167(class_5602.field_53017)),
                    class_954.field_4795,
                    class_4507.class_9995.field_53232);
        }

        protected int numStuck(T renderState) {
            int[] data = EntityPinCushions.PINCUSHION_DATA.get(renderState);
            return data != null ? data[1] : 0;
        }
    }

    public static class BeeStingerLayer<T extends class_10042, M extends class_583<T>> extends PinCushionLayer<T, M> {
        private static final class_2960 BEE_STINGER_LOCATION = class_2960.method_60656("textures/entity/bee/bee_stinger.png");

        public BeeStingerLayer(class_5617.class_5618 context, class_922<?, T, M> renderer) {
            super(renderer,
                    new class_9942(context.method_32167(class_5602.field_53020)),
                    BEE_STINGER_LOCATION,
                    class_4507.class_9995.field_53233);
        }

        protected int numStuck(T renderState) {
            int[] data = EntityPinCushions.PINCUSHION_DATA.get(renderState);
            return data != null ? data[2] : 0;
        }
    }
}
